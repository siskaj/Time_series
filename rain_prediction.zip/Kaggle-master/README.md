# Kaggle

Otto ensemble of DNN and GBM models used in my submissions to the competition.

